---
name: visual-critic
description: Inspects real Blender renders of stylized VTuber models, facial expressions and animation to identify and repair top visual defects. Use at every milestone, never from logs alone.
---
# Visual Critic

1. Run `scripts/render_review.py` or equivalent to generate actual front, 3/4, side, back and face_close renders. Use identical camera/lights during before/after comparisons.
2. **Inspect each PNG visually** using image-capable viewing tool. If agent cannot view PNGs, STOP, report `VISUAL_CHECK_UNAVAILABLE`, and request human review or tool setup.
3. Compare to approved user reference(s), distinguishing reference fidelity from style quality. Read `docs/QUALITY_RUBRIC.md`; score only assessable categories and mark remaining as N/A.
4. Record top 3 specific flaws with location, evidence file, likely root cause and one surgical fix each. Examples: left eyelid intersects iris at 60% blink; cheek too narrow in 3/4; front bangs cover eyebrows in head pitch.
5. Apply one targeted revision batch, then rerender. Up to 3 repair cycles per gate; escalate to another method/base mesh or ask for guidance beyond that.
6. Do not optimize lighting/camera to hide defects. Use neutral-light technical renders for geometry review and beauty renders for artistic review.
7. Always distinguish automatically checked properties from aesthetic judgments. Save `outputs/reports/visual_review.md` with concrete before/after paths.

**Exit:** genuine reviewed previews, top-issues log, and human approval requirement for subjective face identity.

## v0.2 broadcast-focused review
- Include the OBS-scale portrait crop and face close-up on each design gate; a beautiful full-body render does not prove the webcam-framed face works.
- Flag bangs obscuring eyes, expression shape intersections, asymmetric eyelid motion, hair collisions during head turns, unreadable mouth motion, and face flicker. Do not treat soft focus or aggressive bloom as a fix.
