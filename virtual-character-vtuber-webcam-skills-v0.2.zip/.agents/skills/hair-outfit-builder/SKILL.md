---
name: hair-outfit-builder
description: Produces coherent stylized VTuber hair clumps, outfit layers and accessories that keep appealing silhouettes and rig cleanly in Blender. Use after approved face blockout.
---
# Hair and Outfit Builder

1. Plan hair hierarchy: skull cap, primary silhouette locks, secondary locks, a few accent strands. Distinguish bangs from side/back hair with depth.
2. Prefer purposeful tapered sections and controllable curve/mesh profiles; avoid forests of cylinders and floating spikes. Check scalp coverage and head movement clearance.
3. Outfit from major shape masses: neck/torso, sleeves, gloves/accessories. Prioritize streamer upper body; reduce hidden polygon/detail costs.
4. Separate rigid accessories from bend regions; choose bone-parenting for rigid parts and weighted mesh for cloth, with simplified secondary-motion rig later if desired.
5. Test camera angles and movements for collisions: bangs vs eyebrows/eyes, hair vs shoulders, sleeves vs wrists, cloth vs hips.
6. Use 3-color hierarchy unless brief specifies otherwise. Validate color/value separation with diffuse-only/neutral lighting preview.
7. Record all external textures and materials in license manifest.

**Exit:** readable front/3/4 hair+outfit silhouette, no major default-pose clipping, documented object naming and attachment plan.
