"""Blender scene report (technical, NOT a visual-quality certificate).

Usage:
  blender --background model.blend --python scripts/audit_blend.py -- --output outputs/reports/scene_audit.json
"""
import argparse
import json
import sys
from pathlib import Path

try:
    import bpy
    import bmesh
except ImportError as exc:
    raise SystemExit('This script must be run by Blender Python (`blender --python`).') from exc


def cli_args():
    raw = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    parser = argparse.ArgumentParser(description='Blender scene technical audit')
    parser.add_argument('--output', required=True, help='Path of output JSON report')
    return parser.parse_args(raw)


def audit_mesh(obj):
    mesh = obj.data
    bmesh_object = bmesh.new()
    try:
        bmesh_object.from_mesh(mesh)
        loose_verts = sum(1 for vert in bmesh_object.verts if not vert.link_edges)
        boundary_edges = sum(1 for edge in bmesh_object.edges if edge.is_boundary)
        non_manifold_edges = sum(1 for edge in bmesh_object.edges if not edge.is_manifold)
    finally:
        bmesh_object.free()

    skin_groups = []
    if obj.vertex_groups:
        skin_groups = [g.name for g in obj.vertex_groups]
    shapekeys = []
    if mesh.shape_keys:
        shapekeys = [block.name for block in mesh.shape_keys.key_blocks if block.name != 'Basis']

    return {
        'name': obj.name,
        'vertices': len(mesh.vertices),
        'polygons': len(mesh.polygons),
        'triangles': sum(max(0, len(p.vertices) - 2) for p in mesh.polygons),
        'uv_layers': [uv.name for uv in mesh.uv_layers],
        'shape_keys': shapekeys,
        'vertex_groups': skin_groups,
        'armature_modifiers': [m.object.name for m in obj.modifiers if m.type == 'ARMATURE' and m.object],
        'loose_vertices': loose_verts,
        'non_manifold_edges_including_boundaries': non_manifold_edges,
        'boundary_edges': boundary_edges,
        'notes': 'Open shells can legitimately have boundary edges; requires artist review.',
    }


def main():
    args = cli_args()
    objects = list(bpy.data.objects)
    mesh_report = [audit_mesh(o) for o in objects if o.type == 'MESH']
    arms = [o for o in objects if o.type == 'ARMATURE']
    report = {
        'blender_version': bpy.app.version_string,
        'blend_file': bpy.data.filepath or 'UNSAVED',
        'total_objects': len(objects),
        'mesh_count': len(mesh_report),
        'triangle_count_total': sum(m['triangles'] for m in mesh_report),
        'mesh_report': mesh_report,
        'armatures': [{'name': a.name, 'bone_count': len(a.data.bones),
                       'bone_names': [bone.name for bone in a.data.bones]} for a in arms],
        'actions': [{'name': a.name, 'frame_range': list(a.frame_range)} for a in bpy.data.actions],
        'potential_issues': [],
        'visual_approval': 'NOT_TESTED',
        'vrm_export_validated': False,
        'external_vtuber_app_validated': False,
    }
    if not mesh_report:
        report['potential_issues'].append('No mesh objects.')
    if not arms:
        report['potential_issues'].append('No armatures. Acceptable before rigging phase.')
    if not any(m['shape_keys'] for m in mesh_report):
        report['potential_issues'].append('No face shape keys found. Acceptable before rigging phase.')
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('AUDIT_WRITTEN:', out.resolve())
    print('MESHES:', len(mesh_report), 'TRIANGLES:', report['triangle_count_total'])


if __name__ == '__main__':
    main()
